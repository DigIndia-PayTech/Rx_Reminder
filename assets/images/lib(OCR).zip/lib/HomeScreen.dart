import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutterocr/Wigets.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_picker_gallery_camera/image_picker_gallery_camera.dart';
import 'package:tesseract_ocr/tesseract_ocr.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<File> attachmentList = [];
  bool _scanning = false;
  String _extractText = 'Your Extracted text appears here';
  File _pickedImage;
  File croppedFile;
  final picker = ImagePicker();

  Future<int> deleteFile() async {
    try {
      final file = croppedFile;
      await file.delete();
      return 1;
    } catch (e) {
      return 0;
    }
  }

  clearImage() {
    setState(() {
      croppedFile = null;
    });
  }

  getImage(imageSource) async {
    print("Getting Image");
    final _pickedImage = await picker.getImage(source: imageSource);
    File temp = File(_pickedImage.path);
    setState(() {
      _scanning = true;
    });
    cropImage(temp);
  }

  cropImage(File pickedImage) async {
    print("Cropping Image");
    croppedFile = await ImageCropper.cropImage(
        sourcePath: pickedImage.path,
        aspectRatioPresets: [
          CropAspectRatioPreset.square,
          CropAspectRatioPreset.ratio3x2,
          CropAspectRatioPreset.original,
          CropAspectRatioPreset.ratio4x3,
          CropAspectRatioPreset.ratio16x9
        ],
        androidUiSettings: AndroidUiSettings(
            toolbarTitle: 'Edit image',
            toolbarColor: Colors.deepOrange,
            toolbarWidgetColor: Colors.white,
            initAspectRatio: CropAspectRatioPreset.original,
            lockAspectRatio: false),
        iosUiSettings: IOSUiSettings(
          minimumAspectRatio: 1.0,
        ));
    extractText(croppedFile);
    return croppedFile;
  }

  extractText(file) async {
    print("Extracting Text");
    _extractText = await TesseractOcr.extractText(file.path);
    setState(() {
      _scanning = false;
      print("End");
    });
  }

  Future camImage(ImgSource source) async {
    try {
      var image = await ImagePickerGC.pickImage(
        imageQuality: 80,
        context: context,
        source: source,
        cameraIcon: Icon(
          Icons.add,
          color: Colors.red,
        ),
      );
      print('Original path: ${image.path}');
    } catch (e) {
      print("erro image1$e");
    }
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.light);
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Colors.black.withOpacity(0.7),
          title: Text('Simple OCR'),
        ),
        body: ListView(
          children: [
            Container(
              height: MediaQuery.of(context).size.height -
                  AppBar().preferredSize.height,
              width: MediaQuery.of(context).size.width,
              child: Column(
                children: [
                  Row(
                    children: [
                      InkWell(
                        onTap: () async {
                          getImage(ImageSource.camera);
                        },
                        child: iconCard(
                          context,
                          Icon(Icons.camera, size: 50),
                          'Get text \nfrom camera',
                          EdgeInsets.fromLTRB(20, 20, 10, 0),
                        ),
                      ),
                      InkWell(
                        onTap: () async {
                          getImage(ImageSource.gallery);
                        },
                        child: Column(
                          children: [
                            iconCard(
                              context,
                              Icon(Icons.photo, size: 50),
                              'Get text \nfrom Gallery',
                              EdgeInsets.fromLTRB(10, 20, 20, 0),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      iconCard(
                        context,
                        _scanning
                            ? Center(
                                child: CircularProgressIndicator(
                                  backgroundColor: Colors.black,
                                  strokeWidth: 6,
                                ),
                              )
                            : Icon(
                                Icons.arrow_forward_outlined,
                                size: 50,
                              ),
                        'Convert',
                        EdgeInsets.fromLTRB(20, 20, 10, 0),
                      ),
                      InkWell(
                        onTap: () {
                          clearImage();
                          setState(() {
                            _extractText = 'Your Extracted text appears here';
                          });
                        },
                        child: Column(
                          children: [
                            iconCard(
                              context,
                              Icon(
                                Icons.delete,
                                size: 50,
                              ),
                              'Clear',
                              EdgeInsets.fromLTRB(10, 20, 20, 0),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: "your text"));
                      },
                      child: Container(
                        margin: EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.black),
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.grey[300],
                        ),
                        child: Center(
                          child: SingleChildScrollView(
                            child: Text(
                              _extractText,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 18,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            (_pickedImage == null) && (croppedFile == null)
                ? Container()
                : croppedFile != null
                    ? Container(
                        height: 300,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black),
                            color: Colors.grey[300],
                            image: DecorationImage(
                              image: FileImage(croppedFile),
                              fit: BoxFit.fill,
                            )),
                      )
                    : Container(
                        height: 300,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.black),
                          color: Colors.grey[300],
                        ),
                        child: Icon(
                          Icons.image,
                          size: 100,
                        ),
                      ),
          ],
        ),
      ),
    );
  }
}
