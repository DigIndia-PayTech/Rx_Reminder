import 'package:flutter/material.dart';
import 'package:flutterocr/HomeScreen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeScreen(),
    );
  }
}





// import 'dart:io';
//
// // import 'package:file_picker/file_picker.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_spinkit/flutter_spinkit.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:tesseract_ocr/tesseract_ocr.dart';
//
// void main() => runApp(MyApp());
//
// class MyApp extends StatefulWidget {
//   @override
//   _MyAppState createState() => _MyAppState();
// }
//
// class _MyAppState extends State<MyApp> {
//   bool _scanning = false;
//   String _extractText = '';
//   int _scanTime = 0;
//   var _image;
//   final picker = ImagePicker();
//   Future getImage() async {
//     final pickedFile = await picker.getImage(source: ImageSource.gallery);
//
//     setState(() {
//       if (pickedFile != null) {
//         _image = File(pickedFile.path);
//       } else {
//         print('No image selected.');
//       }
//     });
//   }
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//           appBar: AppBar(
//             title: const Text('Tesseract OCR'),
//           ),
//           body: Container(
//             padding: EdgeInsets.all(16),
//             child: ListView(
//               children: <Widget>[
//                 Center(
//                   child: _image == null
//                       ? Text('No image selected.')
//                       : Image.file(_image),
//                 ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     RaisedButton(
//                       child: Text('Select image'),
//                       onPressed: () async {
//
//                         getImage();
//
//                       },
//                     ),
//                     // It doesn't spin, because scanning hangs thread for now
//
//
//                     new RaisedButton(
//                       child:  Text('scan'),
//                         onPressed:() async {
//                           _scanning = true;
//                           setState(() {});
//                           var watch = Stopwatch()..start();
//                           print('fff');
//                           _extractText = await TesseractOcr.extractText(_image.toString());
//                           print('hhh');
//                           _scanTime = watch.elapsedMilliseconds;
//                           _scanning = false;
//                           setState(() {});
//
//                     } ),
//                     _scanning
//                         ? SpinKitCircle(
//                       color: Colors.black,
//                     )
//                         : Icon(Icons.done),
//                   ],
//                 ),
//                 SizedBox(
//                   height: 16,
//                 ),
//                 Text(
//                   'Scanning took $_scanTime ms',
//                   style: TextStyle(color: Colors.red),
//                 ),
//                 SizedBox(
//                   height: 16,
//                 ),
//                 Center(child: SelectableText(_extractText)),
//               ],
//             ),
//           )),
//     );
//   }
// }